# nodejs-yui
This is node.js with yui

  First install node.js on your machine.
  Extract this file in the directory.
  From terminal window enter to the directory and run 'npm install' may be sudo user permission required for this.
  Run 'node server'.
  Goto http://localhost:3000